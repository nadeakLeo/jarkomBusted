#ifndef BIT_H
#define BIT_H

#include "dcomm.h"

string makeCRC(string bit);

#endif
